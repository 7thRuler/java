package Graphics;
public class Area{
	public void circle(int a){
		System.out.println("Area = "+3.14*a*a);
	}
	public void rectangle(int a,int b){
		System.out.println("Area = "+a*b);
	}
	public void square(int a){
		System.out.println("Area = "+a*a);
	}
	public void triangle(int a,int b,int c){
		System.out.println("Area = "+.5*a*b*c);
	}
}
